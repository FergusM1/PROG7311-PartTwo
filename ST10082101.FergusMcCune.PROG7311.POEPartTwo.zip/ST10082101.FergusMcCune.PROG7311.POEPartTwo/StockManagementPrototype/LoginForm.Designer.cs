﻿namespace StockManagementPrototype
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headingLbl = new System.Windows.Forms.Label();
            this.usernameLbl = new System.Windows.Forms.Label();
            this.usrnameTB = new System.Windows.Forms.TextBox();
            this.passwordLbl = new System.Windows.Forms.Label();
            this.passwordTB = new System.Windows.Forms.TextBox();
            this.loginBtn = new System.Windows.Forms.Button();
            this.selectLbl = new System.Windows.Forms.Label();
            this.employeeRB = new System.Windows.Forms.RadioButton();
            this.farmerRB = new System.Windows.Forms.RadioButton();
            this.usrErrorLbl = new System.Windows.Forms.Label();
            this.passErrorLbl = new System.Windows.Forms.Label();
            this.selectErrorLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // headingLbl
            // 
            this.headingLbl.AutoSize = true;
            this.headingLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headingLbl.Location = new System.Drawing.Point(172, 44);
            this.headingLbl.Name = "headingLbl";
            this.headingLbl.Size = new System.Drawing.Size(419, 31);
            this.headingLbl.TabIndex = 0;
            this.headingLbl.Text = "Farm Central Stock System Login";
            // 
            // usernameLbl
            // 
            this.usernameLbl.AutoSize = true;
            this.usernameLbl.Location = new System.Drawing.Point(175, 126);
            this.usernameLbl.Name = "usernameLbl";
            this.usernameLbl.Size = new System.Drawing.Size(183, 13);
            this.usernameLbl.TabIndex = 1;
            this.usernameLbl.Text = "Please enter your account username:";
            // 
            // usrnameTB
            // 
            this.usrnameTB.Location = new System.Drawing.Point(389, 123);
            this.usrnameTB.Name = "usrnameTB";
            this.usrnameTB.Size = new System.Drawing.Size(228, 20);
            this.usrnameTB.TabIndex = 2;
            // 
            // passwordLbl
            // 
            this.passwordLbl.AutoSize = true;
            this.passwordLbl.Location = new System.Drawing.Point(175, 195);
            this.passwordLbl.Name = "passwordLbl";
            this.passwordLbl.Size = new System.Drawing.Size(182, 13);
            this.passwordLbl.TabIndex = 3;
            this.passwordLbl.Text = "Please enter your account password:";
            // 
            // passwordTB
            // 
            this.passwordTB.Location = new System.Drawing.Point(389, 192);
            this.passwordTB.Name = "passwordTB";
            this.passwordTB.PasswordChar = '*';
            this.passwordTB.Size = new System.Drawing.Size(228, 20);
            this.passwordTB.TabIndex = 4;
            // 
            // loginBtn
            // 
            this.loginBtn.Location = new System.Drawing.Point(389, 325);
            this.loginBtn.Name = "loginBtn";
            this.loginBtn.Size = new System.Drawing.Size(75, 23);
            this.loginBtn.TabIndex = 5;
            this.loginBtn.Text = "Login";
            this.loginBtn.UseVisualStyleBackColor = true;
            this.loginBtn.Click += new System.EventHandler(this.loginBtn_Click);
            // 
            // selectLbl
            // 
            this.selectLbl.AutoSize = true;
            this.selectLbl.Location = new System.Drawing.Point(175, 248);
            this.selectLbl.Name = "selectLbl";
            this.selectLbl.Size = new System.Drawing.Size(161, 13);
            this.selectLbl.TabIndex = 6;
            this.selectLbl.Text = "Please select your account type:";
            // 
            // employeeRB
            // 
            this.employeeRB.AutoSize = true;
            this.employeeRB.Location = new System.Drawing.Point(389, 248);
            this.employeeRB.Name = "employeeRB";
            this.employeeRB.Size = new System.Drawing.Size(71, 17);
            this.employeeRB.TabIndex = 7;
            this.employeeRB.TabStop = true;
            this.employeeRB.Text = "Employee";
            this.employeeRB.UseVisualStyleBackColor = true;
            // 
            // farmerRB
            // 
            this.farmerRB.AutoSize = true;
            this.farmerRB.Location = new System.Drawing.Point(494, 248);
            this.farmerRB.Name = "farmerRB";
            this.farmerRB.Size = new System.Drawing.Size(57, 17);
            this.farmerRB.TabIndex = 8;
            this.farmerRB.TabStop = true;
            this.farmerRB.Text = "Farmer";
            this.farmerRB.UseVisualStyleBackColor = true;
            // 
            // usrErrorLbl
            // 
            this.usrErrorLbl.AutoSize = true;
            this.usrErrorLbl.ForeColor = System.Drawing.Color.Red;
            this.usrErrorLbl.Location = new System.Drawing.Point(642, 126);
            this.usrErrorLbl.Name = "usrErrorLbl";
            this.usrErrorLbl.Size = new System.Drawing.Size(0, 13);
            this.usrErrorLbl.TabIndex = 9;
            // 
            // passErrorLbl
            // 
            this.passErrorLbl.AutoSize = true;
            this.passErrorLbl.ForeColor = System.Drawing.Color.Red;
            this.passErrorLbl.Location = new System.Drawing.Point(642, 195);
            this.passErrorLbl.Name = "passErrorLbl";
            this.passErrorLbl.Size = new System.Drawing.Size(0, 13);
            this.passErrorLbl.TabIndex = 10;
            // 
            // selectErrorLbl
            // 
            this.selectErrorLbl.AutoSize = true;
            this.selectErrorLbl.ForeColor = System.Drawing.Color.Red;
            this.selectErrorLbl.Location = new System.Drawing.Point(642, 250);
            this.selectErrorLbl.Name = "selectErrorLbl";
            this.selectErrorLbl.Size = new System.Drawing.Size(0, 13);
            this.selectErrorLbl.TabIndex = 11;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.selectErrorLbl);
            this.Controls.Add(this.passErrorLbl);
            this.Controls.Add(this.usrErrorLbl);
            this.Controls.Add(this.farmerRB);
            this.Controls.Add(this.employeeRB);
            this.Controls.Add(this.selectLbl);
            this.Controls.Add(this.loginBtn);
            this.Controls.Add(this.passwordTB);
            this.Controls.Add(this.passwordLbl);
            this.Controls.Add(this.usrnameTB);
            this.Controls.Add(this.usernameLbl);
            this.Controls.Add(this.headingLbl);
            this.Name = "LoginForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label headingLbl;
        private System.Windows.Forms.Label usernameLbl;
        private System.Windows.Forms.TextBox usrnameTB;
        private System.Windows.Forms.Label passwordLbl;
        private System.Windows.Forms.TextBox passwordTB;
        private System.Windows.Forms.Button loginBtn;
        private System.Windows.Forms.Label selectLbl;
        private System.Windows.Forms.RadioButton employeeRB;
        private System.Windows.Forms.RadioButton farmerRB;
        private System.Windows.Forms.Label usrErrorLbl;
        private System.Windows.Forms.Label passErrorLbl;
        private System.Windows.Forms.Label selectErrorLbl;
    }
}

