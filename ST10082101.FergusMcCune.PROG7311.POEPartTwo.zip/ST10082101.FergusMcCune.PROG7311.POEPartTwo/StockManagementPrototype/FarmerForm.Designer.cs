﻿namespace StockManagementPrototype
{
    partial class FarmerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.farmerProductsGV = new System.Windows.Forms.DataGridView();
            this.headingLbl = new System.Windows.Forms.Label();
            this.newProdLbl = new System.Windows.Forms.Label();
            this.typeLbl = new System.Windows.Forms.Label();
            this.typeTB = new System.Windows.Forms.TextBox();
            this.typeErrLbl = new System.Windows.Forms.Label();
            this.quantityLbl = new System.Windows.Forms.Label();
            this.quantityTB = new System.Windows.Forms.TextBox();
            this.quantityErrLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.priceTB = new System.Windows.Forms.TextBox();
            this.priceErrLbl = new System.Windows.Forms.Label();
            this.dateLbl = new System.Windows.Forms.Label();
            this.supplyMC = new System.Windows.Forms.MonthCalendar();
            this.dateErrLbl = new System.Windows.Forms.Label();
            this.addProductBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.farmerProductsGV)).BeginInit();
            this.SuspendLayout();
            // 
            // farmerProductsGV
            // 
            this.farmerProductsGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.farmerProductsGV.Location = new System.Drawing.Point(12, 161);
            this.farmerProductsGV.Name = "farmerProductsGV";
            this.farmerProductsGV.Size = new System.Drawing.Size(451, 255);
            this.farmerProductsGV.TabIndex = 0;
            // 
            // headingLbl
            // 
            this.headingLbl.AutoSize = true;
            this.headingLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headingLbl.Location = new System.Drawing.Point(13, 111);
            this.headingLbl.Name = "headingLbl";
            this.headingLbl.Size = new System.Drawing.Size(169, 24);
            this.headingLbl.TabIndex = 1;
            this.headingLbl.Text = "Supplied Products:";
            // 
            // newProdLbl
            // 
            this.newProdLbl.AutoSize = true;
            this.newProdLbl.Location = new System.Drawing.Point(627, 52);
            this.newProdLbl.Name = "newProdLbl";
            this.newProdLbl.Size = new System.Drawing.Size(137, 13);
            this.newProdLbl.TabIndex = 2;
            this.newProdLbl.Text = "Enter a new product below:";
            // 
            // typeLbl
            // 
            this.typeLbl.AutoSize = true;
            this.typeLbl.Location = new System.Drawing.Point(488, 121);
            this.typeLbl.Name = "typeLbl";
            this.typeLbl.Size = new System.Drawing.Size(149, 13);
            this.typeLbl.TabIndex = 3;
            this.typeLbl.Text = "Please enter the product type:";
            // 
            // typeTB
            // 
            this.typeTB.Location = new System.Drawing.Point(643, 118);
            this.typeTB.Name = "typeTB";
            this.typeTB.Size = new System.Drawing.Size(121, 20);
            this.typeTB.TabIndex = 4;
            // 
            // typeErrLbl
            // 
            this.typeErrLbl.AutoSize = true;
            this.typeErrLbl.ForeColor = System.Drawing.Color.Red;
            this.typeErrLbl.Location = new System.Drawing.Point(770, 125);
            this.typeErrLbl.Name = "typeErrLbl";
            this.typeErrLbl.Size = new System.Drawing.Size(0, 13);
            this.typeErrLbl.TabIndex = 5;
            // 
            // quantityLbl
            // 
            this.quantityLbl.AutoSize = true;
            this.quantityLbl.Location = new System.Drawing.Point(471, 181);
            this.quantityLbl.Name = "quantityLbl";
            this.quantityLbl.Size = new System.Drawing.Size(166, 13);
            this.quantityLbl.TabIndex = 6;
            this.quantityLbl.Text = "Please enter the product quantity:";
            // 
            // quantityTB
            // 
            this.quantityTB.Location = new System.Drawing.Point(643, 178);
            this.quantityTB.Name = "quantityTB";
            this.quantityTB.Size = new System.Drawing.Size(121, 20);
            this.quantityTB.TabIndex = 7;
            // 
            // quantityErrLbl
            // 
            this.quantityErrLbl.AutoSize = true;
            this.quantityErrLbl.ForeColor = System.Drawing.Color.Red;
            this.quantityErrLbl.Location = new System.Drawing.Point(770, 185);
            this.quantityErrLbl.Name = "quantityErrLbl";
            this.quantityErrLbl.Size = new System.Drawing.Size(0, 13);
            this.quantityErrLbl.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(485, 239);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Please enter the product price:";
            // 
            // priceTB
            // 
            this.priceTB.Location = new System.Drawing.Point(643, 239);
            this.priceTB.Name = "priceTB";
            this.priceTB.Size = new System.Drawing.Size(121, 20);
            this.priceTB.TabIndex = 10;
            // 
            // priceErrLbl
            // 
            this.priceErrLbl.AutoSize = true;
            this.priceErrLbl.ForeColor = System.Drawing.Color.Red;
            this.priceErrLbl.Location = new System.Drawing.Point(770, 246);
            this.priceErrLbl.Name = "priceErrLbl";
            this.priceErrLbl.Size = new System.Drawing.Size(0, 13);
            this.priceErrLbl.TabIndex = 11;
            // 
            // dateLbl
            // 
            this.dateLbl.AutoSize = true;
            this.dateLbl.Location = new System.Drawing.Point(493, 311);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(144, 13);
            this.dateLbl.TabIndex = 12;
            this.dateLbl.Text = "Please enter the supply date:";
            // 
            // supplyMC
            // 
            this.supplyMC.Location = new System.Drawing.Point(643, 311);
            this.supplyMC.MaxSelectionCount = 1;
            this.supplyMC.Name = "supplyMC";
            this.supplyMC.TabIndex = 13;
            // 
            // dateErrLbl
            // 
            this.dateErrLbl.AutoSize = true;
            this.dateErrLbl.ForeColor = System.Drawing.Color.Red;
            this.dateErrLbl.Location = new System.Drawing.Point(874, 311);
            this.dateErrLbl.Name = "dateErrLbl";
            this.dateErrLbl.Size = new System.Drawing.Size(0, 13);
            this.dateErrLbl.TabIndex = 14;
            // 
            // addProductBtn
            // 
            this.addProductBtn.Location = new System.Drawing.Point(643, 498);
            this.addProductBtn.Name = "addProductBtn";
            this.addProductBtn.Size = new System.Drawing.Size(77, 23);
            this.addProductBtn.TabIndex = 15;
            this.addProductBtn.Text = "Add Product";
            this.addProductBtn.UseVisualStyleBackColor = true;
            this.addProductBtn.Click += new System.EventHandler(this.addProductBtn_Click);
            // 
            // FarmerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 537);
            this.Controls.Add(this.addProductBtn);
            this.Controls.Add(this.dateErrLbl);
            this.Controls.Add(this.supplyMC);
            this.Controls.Add(this.dateLbl);
            this.Controls.Add(this.priceErrLbl);
            this.Controls.Add(this.priceTB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.quantityErrLbl);
            this.Controls.Add(this.quantityTB);
            this.Controls.Add(this.quantityLbl);
            this.Controls.Add(this.typeErrLbl);
            this.Controls.Add(this.typeTB);
            this.Controls.Add(this.typeLbl);
            this.Controls.Add(this.newProdLbl);
            this.Controls.Add(this.headingLbl);
            this.Controls.Add(this.farmerProductsGV);
            this.Name = "FarmerForm";
            this.Text = "FarmerForm";
            ((System.ComponentModel.ISupportInitialize)(this.farmerProductsGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView farmerProductsGV;
        private System.Windows.Forms.Label headingLbl;
        private System.Windows.Forms.Label newProdLbl;
        private System.Windows.Forms.Label typeLbl;
        private System.Windows.Forms.TextBox typeTB;
        private System.Windows.Forms.Label typeErrLbl;
        private System.Windows.Forms.Label quantityLbl;
        private System.Windows.Forms.TextBox quantityTB;
        private System.Windows.Forms.Label quantityErrLbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox priceTB;
        private System.Windows.Forms.Label priceErrLbl;
        private System.Windows.Forms.Label dateLbl;
        private System.Windows.Forms.MonthCalendar supplyMC;
        private System.Windows.Forms.Label dateErrLbl;
        private System.Windows.Forms.Button addProductBtn;
    }
}