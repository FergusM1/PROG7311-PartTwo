﻿namespace StockManagementPrototype
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.empHeadingLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.farmUsrnameTB = new System.Windows.Forms.TextBox();
            this.errLbl = new System.Windows.Forms.Label();
            this.addBtn = new System.Windows.Forms.Button();
            this.getBtn = new System.Windows.Forms.Button();
            this.confirmPasswordUserControl1 = new StockManagementPrototype.ConfirmPasswordUserControl();
            this.SuspendLayout();
            // 
            // empHeadingLbl
            // 
            this.empHeadingLbl.AutoSize = true;
            this.empHeadingLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empHeadingLbl.Location = new System.Drawing.Point(225, 80);
            this.empHeadingLbl.Name = "empHeadingLbl";
            this.empHeadingLbl.Size = new System.Drawing.Size(308, 31);
            this.empHeadingLbl.TabIndex = 0;
            this.empHeadingLbl.Text = "Employee Stock System";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(228, 159);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Please enter the farmer\'s username:";
            // 
            // farmUsrnameTB
            // 
            this.farmUsrnameTB.Location = new System.Drawing.Point(409, 156);
            this.farmUsrnameTB.Name = "farmUsrnameTB";
            this.farmUsrnameTB.Size = new System.Drawing.Size(157, 20);
            this.farmUsrnameTB.TabIndex = 2;
            // 
            // errLbl
            // 
            this.errLbl.AutoSize = true;
            this.errLbl.ForeColor = System.Drawing.Color.Red;
            this.errLbl.Location = new System.Drawing.Point(584, 159);
            this.errLbl.Name = "errLbl";
            this.errLbl.Size = new System.Drawing.Size(0, 13);
            this.errLbl.TabIndex = 3;
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(266, 228);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(75, 23);
            this.addBtn.TabIndex = 4;
            this.addBtn.Text = "Add Farmer";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // getBtn
            // 
            this.getBtn.Location = new System.Drawing.Point(409, 228);
            this.getBtn.Name = "getBtn";
            this.getBtn.Size = new System.Drawing.Size(89, 23);
            this.getBtn.TabIndex = 5;
            this.getBtn.Text = "Get Products";
            this.getBtn.UseVisualStyleBackColor = true;
            this.getBtn.Click += new System.EventHandler(this.getBtn_Click);
            // 
            // confirmPasswordUserControl1
            // 
            this.confirmPasswordUserControl1.Location = new System.Drawing.Point(187, 266);
            this.confirmPasswordUserControl1.Name = "confirmPasswordUserControl1";
            this.confirmPasswordUserControl1.Size = new System.Drawing.Size(421, 235);
            this.confirmPasswordUserControl1.TabIndex = 6;
            this.confirmPasswordUserControl1.Visible = false;
            // 
            // EmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 547);
            this.Controls.Add(this.confirmPasswordUserControl1);
            this.Controls.Add(this.getBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.errLbl);
            this.Controls.Add(this.farmUsrnameTB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.empHeadingLbl);
            this.Name = "EmployeeForm";
            this.Text = "EmployeeForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label empHeadingLbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox farmUsrnameTB;
        private System.Windows.Forms.Label errLbl;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button getBtn;
        private ConfirmPasswordUserControl confirmPasswordUserControl1;
    }
}