﻿namespace StockManagementPrototype
{
    partial class ConfirmPasswordUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.passWordLbl = new System.Windows.Forms.Label();
            this.confirmLbl = new System.Windows.Forms.Label();
            this.passwordTB = new System.Windows.Forms.TextBox();
            this.confirmTB = new System.Windows.Forms.TextBox();
            this.errorLbl = new System.Windows.Forms.Label();
            this.confirmErrLbl = new System.Windows.Forms.Label();
            this.createFarmerBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(69, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Confirm Farmer\'s Password";
            // 
            // passWordLbl
            // 
            this.passWordLbl.AutoSize = true;
            this.passWordLbl.Location = new System.Drawing.Point(53, 87);
            this.passWordLbl.Name = "passWordLbl";
            this.passWordLbl.Size = new System.Drawing.Size(84, 13);
            this.passWordLbl.TabIndex = 1;
            this.passWordLbl.Text = "Enter Password:";
            // 
            // confirmLbl
            // 
            this.confirmLbl.AutoSize = true;
            this.confirmLbl.Location = new System.Drawing.Point(53, 124);
            this.confirmLbl.Name = "confirmLbl";
            this.confirmLbl.Size = new System.Drawing.Size(94, 13);
            this.confirmLbl.TabIndex = 2;
            this.confirmLbl.Text = "Confirm Password:";
            // 
            // passwordTB
            // 
            this.passwordTB.Location = new System.Drawing.Point(153, 84);
            this.passwordTB.Name = "passwordTB";
            this.passwordTB.Size = new System.Drawing.Size(143, 20);
            this.passwordTB.TabIndex = 3;
            // 
            // confirmTB
            // 
            this.confirmTB.Location = new System.Drawing.Point(153, 121);
            this.confirmTB.Name = "confirmTB";
            this.confirmTB.Size = new System.Drawing.Size(143, 20);
            this.confirmTB.TabIndex = 4;
            // 
            // errorLbl
            // 
            this.errorLbl.AutoSize = true;
            this.errorLbl.ForeColor = System.Drawing.Color.Red;
            this.errorLbl.Location = new System.Drawing.Point(301, 87);
            this.errorLbl.Name = "errorLbl";
            this.errorLbl.Size = new System.Drawing.Size(0, 13);
            this.errorLbl.TabIndex = 5;
            // 
            // confirmErrLbl
            // 
            this.confirmErrLbl.AutoSize = true;
            this.confirmErrLbl.ForeColor = System.Drawing.Color.Red;
            this.confirmErrLbl.Location = new System.Drawing.Point(304, 124);
            this.confirmErrLbl.Name = "confirmErrLbl";
            this.confirmErrLbl.Size = new System.Drawing.Size(0, 13);
            this.confirmErrLbl.TabIndex = 6;
            // 
            // createFarmerBtn
            // 
            this.createFarmerBtn.Location = new System.Drawing.Point(153, 163);
            this.createFarmerBtn.Name = "createFarmerBtn";
            this.createFarmerBtn.Size = new System.Drawing.Size(126, 23);
            this.createFarmerBtn.TabIndex = 7;
            this.createFarmerBtn.Text = "Create Farmer Account";
            this.createFarmerBtn.UseVisualStyleBackColor = true;
            this.createFarmerBtn.Click += new System.EventHandler(this.createFarmerBtn_Click);
            // 
            // ConfirmPasswordUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.createFarmerBtn);
            this.Controls.Add(this.confirmErrLbl);
            this.Controls.Add(this.errorLbl);
            this.Controls.Add(this.confirmTB);
            this.Controls.Add(this.passwordTB);
            this.Controls.Add(this.confirmLbl);
            this.Controls.Add(this.passWordLbl);
            this.Controls.Add(this.label1);
            this.Name = "ConfirmPasswordUserControl";
            this.Size = new System.Drawing.Size(421, 235);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label passWordLbl;
        private System.Windows.Forms.Label confirmLbl;
        private System.Windows.Forms.TextBox passwordTB;
        private System.Windows.Forms.TextBox confirmTB;
        private System.Windows.Forms.Label errorLbl;
        private System.Windows.Forms.Label confirmErrLbl;
        private System.Windows.Forms.Button createFarmerBtn;
    }
}
