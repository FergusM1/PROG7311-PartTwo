﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace StockManagementPrototype
{
    public partial class FarmerForm : Form
    {
        
        //Values for product quantity, product price and product type ID.
        private static int quantity;
        private static double price;
        private static int prodTypeID;

        #region Farmer Form
        /// <summary>
        /// Displays the product information on the GridView and sets the heading of the form.
        /// </summary>
        public FarmerForm()
        {
            InitializeComponent();
            ViewProductsForm.BindProducts(LoginForm.FarmerID, farmerProductsGV);
            Text = "Farmer Menu";
        }
        #endregion

        #region Get Product Type
        /// <summary>
        /// Checks if the product type entered is valid and if it is then it retrieves the ID of the product type.
        /// </summary>
        /// <returns>validType</returns>
        private bool GetProdType()
        {
            bool validType;
            SqlConnection conn = LoginForm.ConnectToDatabase();
            string farmerSearchQry = "SELECT ProdTypeID FROM PRODUCTTYPE WHERE ProdType = @Type;";
            SqlCommand sqlCommand = new SqlCommand(farmerSearchQry, conn);

            sqlCommand.Parameters.AddWithValue("@Type", typeTB.Text);
            SqlDataReader sdr;
            conn.Open();
            sdr = sqlCommand.ExecuteReader();

            if (sdr.Read())
            {
                prodTypeID = (int)sdr["ProdTypeID"];
                validType = true;
            }
            else
            {
                validType = false;  
            }
            conn.Close();
            return validType;
        }
        #endregion

        #region Check Product Details
        /// <summary>
        /// Checks if the entered product details are valid.
        /// </summary>
        /// <returns>validProduct</returns>
        private bool CheckProductDetails()
        {
            bool validProduct = true;
            bool validType = GetProdType();

            if(validType.Equals(false))
            {
                typeErrLbl.Text = "*Invalid Product Type!";
                validProduct = false;
            }

            if (string.IsNullOrEmpty(typeTB.Text))
            {
                typeErrLbl.Text = "*No value entered!";
                validProduct = false;
            }

            if (string.IsNullOrEmpty(quantityTB.Text))
            {
                quantityErrLbl.Text = "*No value entered!";
                validProduct = false;
            }

            if (string.IsNullOrEmpty(priceTB.Text))
            {
                priceErrLbl.Text = "*No value entered!";
                validProduct = false;
            }

            if (typeTB.Text.Any(char.IsDigit).Equals(true))
            {
                typeErrLbl.Text = "*Product type cannot contain a number!";
                validProduct = false;
            }

            bool validQuantity = int.TryParse(quantityTB.Text, out quantity);
            bool validPrice = double.TryParse(priceTB.Text, out price);
            
            if (validQuantity.Equals(false) || quantity <= 0)
            {
                quantityErrLbl.Text = "*Quantity must be a valid integer above 0!";
                validProduct = false;
            }

            if (validPrice.Equals(false) || price <= 0)
            {
                priceErrLbl.Text = "*Price must be a valid number above 0!";
                validProduct = false;
            }
            return validProduct;
        }
        #endregion

        #region Add Product
        /// <summary>
        /// Adds a new product into the database
        /// </summary>
        private void AddProduct()
        {
            SqlConnection conn = LoginForm.ConnectToDatabase();
            string farmerAddQry = "INSERT INTO PRODUCTS(farmerID, prodTypeID, prodQuantity, prodPrice, supplyDate) VALUES(@ID, @TypeID, @Quantity, @Price, @Date);";
            SqlCommand sqlCommand = new SqlCommand(farmerAddQry, conn);

            sqlCommand.Parameters.AddWithValue("@ID", LoginForm.FarmerID);
            sqlCommand.Parameters.AddWithValue("@TypeID", prodTypeID);
            sqlCommand.Parameters.AddWithValue("@Quantity", quantity);
            sqlCommand.Parameters.AddWithValue("@Price", price);
            sqlCommand.Parameters.AddWithValue("@Date", supplyMC.SelectionStart.Date);

            conn.Open();
            int matchingLogin = sqlCommand.ExecuteNonQuery();

            if (matchingLogin == 1)
            { 
                MessageBox.Show("Product Successfully Added!");
                ViewProductsForm.BindProducts(LoginForm.FarmerID, farmerProductsGV);
            }
            else
            {
                MessageBox.Show("Failed to Add Product!");
            }
            conn.Close();
        }
        #endregion

        #region Add Product Button
        /// <summary>
        /// Adds a product if the products details are valid when the "Add Product" button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addProductBtn_Click(object sender, EventArgs e)
        {
            typeErrLbl.Text = string.Empty;
            quantityErrLbl.Text = string.Empty;
            priceErrLbl.Text = string.Empty;

            bool productValid = CheckProductDetails();

            if (productValid.Equals(true))
            {
                AddProduct();     
            }
            else
            {
                MessageBox.Show("Invalid product details entered!");
            }  
        }
        #endregion
    }
}
