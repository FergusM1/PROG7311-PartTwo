﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockManagementPrototype
{
    public partial class EmployeeForm : Form
    {
        
        //Values for Farmer ID, Farmer Username and a variable to show whether a farmer account already exists 
        private static int farmerID;
        private static string fUsrname;
        public static bool alreadyExists;

        #region Employee Form
        /// <summary>
        /// Sets the Employee form heading
        /// </summary>
        public EmployeeForm()
        {
            InitializeComponent();
            Text = "Employee Menu";
        }
        #endregion

        #region Farmer ID
        /// <summary>
        /// Makes the farmer's ID accessible in other classes.
        /// </summary>
        /// <returns>farmerID</returns>
        public static int FarmerID
        {
            get
            {
                return farmerID;
            }
        }
        #endregion

        #region Farmer Username
        /// <summary>
        /// Makes the farmer username accessible in other classes.
        /// </summary>
        /// <returns>fUsername</returns>
        public static string FarmerUsername
        {
            get
            {
                return fUsrname;
            }
        }
        #endregion

        #region Add Button
        /// <summary>
        /// Checks if the farmer account already exists and makes the password control visisble when the "Add Farmer" button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addBtn_Click(object sender, EventArgs e)
        {
            confirmPasswordUserControl1.Visible = true;
            CheckFarmer();
            fUsrname = farmUsrnameTB.Text;
        }
        #endregion

        #region Add Farmer
        /// <summary>
        /// Adds a new farmer into the database.
        /// </summary>
        public static void AddFarmer()
        {
            SqlConnection conn = LoginForm.ConnectToDatabase();
            string farmerAddQry = "INSERT INTO FARMERS (farmUsername, farmPassword) VALUES(@usrname, @pssword);";
            SqlCommand sqlCommand = new SqlCommand(farmerAddQry, conn);

            sqlCommand.Parameters.AddWithValue("@usrname", fUsrname);
            sqlCommand.Parameters.AddWithValue("@pssword", ConfirmPasswordUserControl.FarmerPassword);

            conn.Open();
            int matchingLogin = sqlCommand.ExecuteNonQuery();

            if (matchingLogin == 1)
            {   
                MessageBox.Show("Farmer Successfully Added!");   
            }
            else
            {
                MessageBox.Show("Failed to Add Farmer!");
            }
            conn.Close();
        }
        #endregion

        #region Get Button
        /// <summary>
        /// Checks for the farmer and gets their details if the "Get Products" button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void getBtn_Click(object sender, EventArgs e)
        {
            GetFarmer();
        }
        #endregion

        #region Get Farmer
        /// <summary>
        /// Checks if the farmer exists and gets their details before displaying their products.
        /// </summary>
        private void GetFarmer()
        {
            SqlConnection conn = LoginForm.ConnectToDatabase();
            string farmerSearchQry = "SELECT farmID FROM FARMERS WHERE farmUsername = @usrname;";
            SqlCommand sqlCommand = new SqlCommand(farmerSearchQry, conn);

            sqlCommand.Parameters.AddWithValue("@usrname", farmUsrnameTB.Text);
            SqlDataReader sdr;
            conn.Open();
            sdr = sqlCommand.ExecuteReader();

            if (sdr.Read())
            {
                farmerID = (int)sdr["farmID"];
                fUsrname = farmUsrnameTB.Text;
                MessageBox.Show("Farmer found");
                ViewProductsForm vpf = new ViewProductsForm();
                vpf.Show();
                Close();
            }
            else
            {
                MessageBox.Show("The account you entered does not exist!");
            }
            conn.Close();
        }
        #endregion

        #region Check Farmer
        /// <summary>
        /// Checks if a farmer account already has the same username.
        /// </summary>
        /// <returns>alreadyExists</returns>
        private void CheckFarmer()
        {
            SqlConnection conn = LoginForm.ConnectToDatabase();
            string farmerSearchQry = "SELECT * FROM FARMERS WHERE farmUsername = @usrname;";
            SqlCommand sqlCommand = new SqlCommand(farmerSearchQry, conn);

            sqlCommand.Parameters.AddWithValue("@usrname", farmUsrnameTB.Text);
            SqlDataReader sdr;
            conn.Open();
            sdr = sqlCommand.ExecuteReader();

            if (sdr.Read())
            {
                MessageBox.Show("An account already exists with this username!");  
                alreadyExists = true;
            }
            else
            {
                alreadyExists = false;
            }
            conn.Close();
        }
        #endregion
    }
}
