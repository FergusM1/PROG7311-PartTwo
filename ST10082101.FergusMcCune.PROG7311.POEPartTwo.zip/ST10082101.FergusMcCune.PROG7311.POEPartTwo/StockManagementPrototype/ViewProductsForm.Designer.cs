﻿namespace StockManagementPrototype
{
    partial class ViewProductsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headingLbl = new System.Windows.Forms.Label();
            this.productsGV = new System.Windows.Forms.DataGridView();
            this.totalBtn = new System.Windows.Forms.Button();
            this.typeRB = new System.Windows.Forms.RadioButton();
            this.dateRB = new System.Windows.Forms.RadioButton();
            this.dateMC = new System.Windows.Forms.MonthCalendar();
            this.dateLbl = new System.Windows.Forms.Label();
            this.sortDateBtn = new System.Windows.Forms.Button();
            this.resetBtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.productsGV)).BeginInit();
            this.SuspendLayout();
            // 
            // headingLbl
            // 
            this.headingLbl.AutoSize = true;
            this.headingLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headingLbl.Location = new System.Drawing.Point(23, 24);
            this.headingLbl.Name = "headingLbl";
            this.headingLbl.Size = new System.Drawing.Size(60, 24);
            this.headingLbl.TabIndex = 0;
            this.headingLbl.Text = "label1";
            // 
            // productsGV
            // 
            this.productsGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.productsGV.Location = new System.Drawing.Point(27, 135);
            this.productsGV.Name = "productsGV";
            this.productsGV.Size = new System.Drawing.Size(473, 278);
            this.productsGV.TabIndex = 1;
            // 
            // totalBtn
            // 
            this.totalBtn.Location = new System.Drawing.Point(27, 85);
            this.totalBtn.Name = "totalBtn";
            this.totalBtn.Size = new System.Drawing.Size(106, 23);
            this.totalBtn.TabIndex = 2;
            this.totalBtn.Text = "View Total Price";
            this.totalBtn.UseVisualStyleBackColor = true;
            this.totalBtn.Click += new System.EventHandler(this.totalBtn_Click);
            // 
            // typeRB
            // 
            this.typeRB.AutoSize = true;
            this.typeRB.Location = new System.Drawing.Point(414, 90);
            this.typeRB.Name = "typeRB";
            this.typeRB.Size = new System.Drawing.Size(120, 17);
            this.typeRB.TabIndex = 3;
            this.typeRB.TabStop = true;
            this.typeRB.Text = "Sort by product type";
            this.typeRB.UseVisualStyleBackColor = true;
            this.typeRB.CheckedChanged += new System.EventHandler(this.typeRB_CheckedChanged);
            // 
            // dateRB
            // 
            this.dateRB.AutoSize = true;
            this.dateRB.Location = new System.Drawing.Point(586, 91);
            this.dateRB.Name = "dateRB";
            this.dateRB.Size = new System.Drawing.Size(112, 17);
            this.dateRB.TabIndex = 4;
            this.dateRB.TabStop = true;
            this.dateRB.Text = "Sort by date range";
            this.dateRB.UseVisualStyleBackColor = true;
            this.dateRB.CheckedChanged += new System.EventHandler(this.dateRB_CheckedChanged);
            // 
            // dateMC
            // 
            this.dateMC.Location = new System.Drawing.Point(536, 173);
            this.dateMC.MaxSelectionCount = 31;
            this.dateMC.Name = "dateMC";
            this.dateMC.TabIndex = 5;
            this.dateMC.Visible = false;
            // 
            // dateLbl
            // 
            this.dateLbl.AutoSize = true;
            this.dateLbl.Location = new System.Drawing.Point(533, 135);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(237, 13);
            this.dateLbl.TabIndex = 6;
            this.dateLbl.Text = "Please select a range of dates for the date range";
            this.dateLbl.Visible = false;
            // 
            // sortDateBtn
            // 
            this.sortDateBtn.Location = new System.Drawing.Point(623, 347);
            this.sortDateBtn.Name = "sortDateBtn";
            this.sortDateBtn.Size = new System.Drawing.Size(75, 23);
            this.sortDateBtn.TabIndex = 7;
            this.sortDateBtn.Text = "Sort by Date";
            this.sortDateBtn.UseVisualStyleBackColor = true;
            this.sortDateBtn.Visible = false;
            this.sortDateBtn.Click += new System.EventHandler(this.sortDateBtn_Click);
            // 
            // resetBtn
            // 
            this.resetBtn.Location = new System.Drawing.Point(181, 85);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(75, 23);
            this.resetBtn.TabIndex = 8;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(27, 419);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(75, 23);
            this.backBtn.TabIndex = 9;
            this.backBtn.Text = "Back";
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // ViewProductsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.resetBtn);
            this.Controls.Add(this.sortDateBtn);
            this.Controls.Add(this.dateLbl);
            this.Controls.Add(this.dateMC);
            this.Controls.Add(this.dateRB);
            this.Controls.Add(this.typeRB);
            this.Controls.Add(this.totalBtn);
            this.Controls.Add(this.productsGV);
            this.Controls.Add(this.headingLbl);
            this.Name = "ViewProductsForm";
            this.Text = "ViewProductsForm";
            ((System.ComponentModel.ISupportInitialize)(this.productsGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label headingLbl;
        private System.Windows.Forms.DataGridView productsGV;
        private System.Windows.Forms.Button totalBtn;
        private System.Windows.Forms.RadioButton typeRB;
        private System.Windows.Forms.RadioButton dateRB;
        private System.Windows.Forms.Label dateLbl;
        private System.Windows.Forms.Button sortDateBtn;
        private System.Windows.Forms.Button resetBtn;
        public System.Windows.Forms.MonthCalendar dateMC;
        private System.Windows.Forms.Button backBtn;
    }
}