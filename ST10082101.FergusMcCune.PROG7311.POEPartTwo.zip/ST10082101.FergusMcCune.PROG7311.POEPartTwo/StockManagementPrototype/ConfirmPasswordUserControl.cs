﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockManagementPrototype
{
    public partial class ConfirmPasswordUserControl : UserControl
    {
        //Value for the farmer's password
        private static string password;

        public ConfirmPasswordUserControl()
        {
            InitializeComponent();
        }

        #region Farmer Password
        /// <summary>
        /// Makes the farmer's password accessible in other classes.
        /// </summary>
        /// <returns>password</returns>
        public static string FarmerPassword
        {
            get {
            return password;
            }
        }
        #endregion

        #region Check Password
        /// <summary>
        /// Checks if the password is valid and adds the farmer account if the password is valid and the account does not exist.
        /// </summary>
        public void CheckPassword()
        {
            errorLbl.Text = string.Empty;
            confirmErrLbl.Text = string.Empty;

            if (String.IsNullOrEmpty(passwordTB.Text))
            {
               errorLbl.Text = "*Missed Entry";
            }

            if (String.IsNullOrEmpty(confirmTB.Text))
            {
                confirmErrLbl.Text = "*Missed Entry";
            }

            if(passwordTB.Text.Equals(confirmTB.Text) && EmployeeForm.alreadyExists.Equals(false))
            {   
                password = passwordTB.Text;
                EmployeeForm.AddFarmer();       
            }
            else
            {
                errorLbl.Text = "*Passwords do not match!";
                confirmErrLbl.Text = "*Passwords do not match!";
            }
        }
        #endregion

        #region Create Farmer Button
        /// <summary>
        /// Checks the passwords if the "Create Farmer Account" button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void createFarmerBtn_Click(object sender, EventArgs e)
        {
            CheckPassword();
        }
        #endregion
    }
}
