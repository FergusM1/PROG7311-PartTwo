﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace StockManagementPrototype
{
    public partial class ViewProductsForm : Form
    {
        //Variable for total price.
        private static string total;

        #region View Products Form
        /// <summary>
        /// Sets the ViewProductForm heading and binds the product information to the GridView.
        /// </summary>
        public ViewProductsForm()
        {
            InitializeComponent();
            headingLbl.Text = "Products for " + EmployeeForm.FarmerUsername;
            BindProducts(EmployeeForm.FarmerID, productsGV);
            Text = "Farmer Products";
        }
        #endregion

        #region Bind Products
        /// <summary>
        /// Retrieves farmer's products from the database to display on the GridView.        
        /// </summary> 
        /// <param name="dgv"></param>
        /// <param name="id"></param>
        public static void BindProducts(int id, DataGridView dgv)
        {
            SqlConnection conn = LoginForm.ConnectToDatabase();
            string getProductsQry = "SELECT ProdType, prodQuantity, prodPrice, supplyDate FROM PRODUCTS, PRODUCTTYPE WHERE farmerID = @ID AND PRODUCTS.prodTypeID = PRODUCTTYPE.ProdTypeID;";
            SqlCommand cmd = new SqlCommand(getProductsQry, conn);
            cmd.Parameters.AddWithValue("@ID", id);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgv.DataSource = dt;
        }
        #endregion

        #region Get Total Price
        /// <summary>
        /// Calculates the total price of all the farmer's products and displays it to the user.
        /// </summary>
        private void GetTotalPrice()
        {
            SqlConnection conn = LoginForm.ConnectToDatabase();
            string totalPriceQry = "SELECT SUM(prodPrice) AS PRICE FROM PRODUCTS WHERE farmerID = @ID;";
            SqlCommand cmd = new SqlCommand(totalPriceQry, conn);
            cmd.Parameters.AddWithValue("@ID", EmployeeForm.FarmerID);

            SqlDataReader sdr;
            conn.Open();
            sdr = cmd.ExecuteReader();

            if (sdr.Read())
            {
                total = sdr["PRICE"].ToString();
                
                MessageBox.Show("The total price of the products is R" + total);
            }
            else
            {
                MessageBox.Show("Error getting product total!");
            }
            conn.Close();
        }
        #endregion

        #region Total Button
        /// <summary>
        /// Retrieves the total price if the user clicks the "View Total Price" button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void totalBtn_Click(object sender, EventArgs e)
        {
            GetTotalPrice();    
        }
        #endregion

        #region Product Type Radio Button
        /// <summary>
        /// Sorts the farmer's products by product type if the "Sort by product type" radio button is checked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void typeRB_CheckedChanged(object sender, EventArgs e)
        {
            if(typeRB.Checked.Equals(true))
            {
                SortByProductType();  
            }
        }
        #endregion

        #region Sort By Product Type
        /// <summary>
        /// Retrieves product information from the database and sorts it by product type to display on the GridView.
        /// </summary>
        public void SortByProductType()
        {
            SqlConnection conn = LoginForm.ConnectToDatabase();
            string sortProductTypeQry = "SELECT ProdType, SUM(prodQuantity) AS TotalQuantity, SUM(prodPrice) AS TotalPrice FROM PRODUCTS, PRODUCTTYPE WHERE farmerID = @ID AND PRODUCTS.prodTypeID = PRODUCTTYPE.ProdTypeID GROUP BY prodType;";
            SqlCommand cmd = new SqlCommand(sortProductTypeQry, conn);
            cmd.Parameters.AddWithValue("@ID", EmployeeForm.FarmerID);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            productsGV.DataSource = dt;
        }
        #endregion

        #region Sort By Date Range
        /// <summary>
        /// Retrieves the product information from the database and sorts it by the date range to display on the GridView.
        /// </summary>
        public void SortByDateRange()
        {
            SqlConnection conn = LoginForm.ConnectToDatabase();
            string sortDateRangeQry = "SELECT ProdType, SUM(prodQuantity) AS TotalQuantity, SUM(prodPrice) AS TotalPrice, supplyDate FROM PRODUCTS, PRODUCTTYPE WHERE farmerID = @ID AND @startDate <= supplyDate AND supplyDate <= @endDate AND PRODUCTS.prodTypeID = PRODUCTTYPE.ProdTypeID GROUP BY prodType, supplyDate;";
            SqlCommand cmd = new SqlCommand(sortDateRangeQry, conn);
            cmd.Parameters.AddWithValue("@ID", EmployeeForm.FarmerID);
            cmd.Parameters.AddWithValue("@startDate", dateMC.SelectionStart.Date);
            cmd.Parameters.AddWithValue("@endDate", dateMC.SelectionEnd.Date);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            productsGV.DataSource = dt;
        }
        #endregion

        #region Date Radio Button
        /// <summary>
        /// Displays the controls to enter the date range if the "Sort by date range" radio button is checked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dateRB_CheckedChanged(object sender, EventArgs e)
        {
            if (dateRB.Checked.Equals(true))
            {
                dateLbl.Visible = true;
                dateMC.Visible = true;
                sortDateBtn.Visible = true;
            }
            else
            {
                dateLbl.Visible = false;
                dateMC.Visible = false;
                sortDateBtn.Visible = false;
            }
        }
        #endregion

        #region Reset Button
        /// <summary>
        /// Resets the GridView to the original product information if the "Reset" button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void resetBtn_Click(object sender, EventArgs e)
        {
            BindProducts(EmployeeForm.FarmerID, productsGV);
        }
        #endregion

        #region Sort Date Button
        /// <summary>
        /// Sorts the product information by the date range if the "Sort by Date" button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void sortDateBtn_Click(object sender, EventArgs e)
        {   
         SortByDateRange();
        }
        #endregion

        #region Back Button
        /// <summary>
        /// Closes the current form and opens the Employee Menu if the "Back" button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void backBtn_Click(object sender, EventArgs e)
        {
            EmployeeForm employeeForm = new EmployeeForm();
            employeeForm.Show();
            Close();
        }
        #endregion
    }
}
