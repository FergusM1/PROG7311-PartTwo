﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace StockManagementPrototype
{
    public partial class LoginForm : Form
    {
        //Value for Farmer ID
        private static int farmerID;

        #region Login Form
        /// <summary>
        /// Sets the Login Page heading
        /// </summary>
        public LoginForm()
        {
            InitializeComponent();
            Text = "Stock Management System Login";
        }
        #endregion

        #region FarmerID
        /// <summary>
        /// Makes the farmerID accessible to other classes
        /// </summary>
        /// <returns>farmerID</returns>
        public static int FarmerID
        {
            get
            {
                return farmerID;
            }
        }
        #endregion

        #region Login Button
        /// <summary>
        /// Checks if the login information is complete and searches for the account that is the selected accounted type.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loginBtn_Click(object sender, EventArgs e)
        {
            
        bool loginCompleted = CheckLogin();

            if (loginCompleted == true)
            {
                SearchForAccount();
            }
            else
            {
                MessageBox.Show("Incomplete login information entered!!");
            }
        }
        #endregion

        #region Check Login
        /// <summary>
        /// Checks if all the login information that has been entered is valid.
        /// </summary>
        /// <returns>completeLogin</returns>
        private Boolean CheckLogin()
        {
            usrErrorLbl.Text = String.Empty;
            passErrorLbl.Text = String.Empty;
            selectErrorLbl.Text = String.Empty;

            bool completeLogin = true;

            if (String.IsNullOrEmpty(usrnameTB.Text))
            {
             usrErrorLbl.Text = "* Empty field!";
             completeLogin = false;
            }

            if (String.IsNullOrEmpty(passwordTB.Text))
            {
                passErrorLbl.Text = "* Empty field!";
                completeLogin = false;
            }

            if (employeeRB.Checked == false && farmerRB.Checked == false)
            {
                selectErrorLbl.Text = "* Didn't select an account type!";
                completeLogin = false;
            }
            return completeLogin;
        }
        #endregion

        #region Search For Account
        /// <summary>
        /// Checks the account type and searches the database for the entered login information.
        /// </summary>
        public void SearchForAccount()
        {
            if (employeeRB.Checked == true)
            {
              SearchEmployeeAccounts();
            }else if (farmerRB.Checked == true)
            {
              SearchFarmerAccounts(); 
            }
        }
        #endregion

        #region Database Connection
        /// <summary>
        /// Connects to database using connection string stored in App.config file and returns the SQL database connection.
        /// </summary>
        /// <returns>connection</returns>
        public static SqlConnection ConnectToDatabase()
        {
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["PrototypeDB"].ConnectionString);
            return connection;
        }
        #endregion

        #region Search Employee Accounts
        /// <summary>
        /// Checks if the entered employee login details are valid.
        /// </summary>
        public void SearchEmployeeAccounts()
        {
            SqlConnection conn = ConnectToDatabase();
            string employeeSearchQry = "SELECT * FROM EMPLOYEES WHERE empUsername = @usrname AND empPassword = @pssword;";
            SqlCommand sqlCommand = new SqlCommand(employeeSearchQry, conn);

            sqlCommand.Parameters.AddWithValue("@usrname", usrnameTB.Text.ToString());
            sqlCommand.Parameters.AddWithValue("@pssword", passwordTB.Text.ToString());
            SqlDataReader sdr;
            
            conn.Open();
            sdr = sqlCommand.ExecuteReader();
            
            if(sdr.Read())
            {
                MessageBox.Show("Login Successful");
                EmployeeForm form = new EmployeeForm();   
                form.Show();    
            }
            else
            {
                MessageBox.Show("The account you entered does not exist!");
            }
                conn.Close(); 
        }
        #endregion

        #region Search Farmer Accounts
        /// <summary>
        /// Checks if the entered farmer login details are valid.
        /// </summary>
        public void SearchFarmerAccounts()
        {
            SqlConnection conn = ConnectToDatabase();
            string farmerSearchQry = "SELECT farmID FROM FARMERS WHERE farmUsername = @usrname AND farmPassword = @pssword;";
            SqlCommand sqlCommand = new SqlCommand(farmerSearchQry, conn);

            sqlCommand.Parameters.AddWithValue("@usrname", usrnameTB.Text);
            sqlCommand.Parameters.AddWithValue("@pssword", passwordTB.Text);
            SqlDataReader sdr;
            conn.Open();
            sdr = sqlCommand.ExecuteReader();

            if (sdr.Read())
            {
                farmerID = (int)sdr["farmID"];
                MessageBox.Show("Login Successful");
                FarmerForm farmerForm = new FarmerForm();
                farmerForm.Show();
            }
            else
            {
                MessageBox.Show("The account you entered does not exist!");
            }
            conn.Close();
        }
        #endregion
    }
}
