Stock Management System Prototype ReadMe

GitHub Repository: https://github.com/FergusM1/PROG7311-PartTwo
IDE: Visual Studio 2022
Target Framework: .Net Framework 4.8

Employee Login Information:
1) Username: Admin  Password: Admin

Farmer Login Information:
1) Username: Farmer John  Password: Password
2) Username: Farmer Max  Password: Admin
3) Username: Farmer Dave  Password: Batman (Note: Farmer Dave does not have any products.)

Product Types:
1) Beef
2) Grain
3) Chicken
4) Fresh Fruit
5) Vegetables

1) After downloading and unzipping the folder, the user can run the application by running StockManagementPrototype.exe
located within the StockManagementPrototype/bin/Debug folder.

2) The Login Page will come up and the user must use the above login details and state whether they are a farmer or an
employee by clicking the corresponding radio buttons.

3.1) If the user is a farmer, the Farmer Menu will be displayed which will show all the farmer's products and allows the
farmer to add a new product to their profile by entering the product information and clicking the "Add Product" button
which will save the new product in the database.

3.2) If the user is an employee, the Employee menu will be display which give the user the option to add a new farmer or
to view the products for a specific farmer by entering the username for the farmer.

4)If the employee wants to add a new farmer, they must enter the new farmer's username and click the "Add Farmer" button which will
display the controls to confirm the farmer's password. Once the password has been entered, the user must click the Create
Farmer Account button which will save the new farmer's login details in the database.

5)If the employee wants to view the products belonging to a specific farmer, they must enter the farmer's username and
click the "Get Products" button, which will open the Farmer Products page.

6)On the Farmer Products page, the employee can get the total price for the farmer's products by clicking the View Total Price
button. The employee can sort the product information by product type or by a date range by clicking the radio buttons.
The "Sort by date range" radio button will display a calendar for the user to enter a date range and apply it to product
information. The employee can select a date range by highlighting all the dates in the calendar that are within the range.
If the employee wants to reset the product information to the original display, they can click the "Reset" button.
If the employee needs to return to the employee menu, they can click the "Back" button.

7) Once the user is done, they can log out by closing the page they are on and can turn off the application by closing the
Login page.







 